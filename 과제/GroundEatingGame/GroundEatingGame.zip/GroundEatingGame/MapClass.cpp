
#include "stdafx.h"
#include "MapClass.h"

Map::Map()
{

}

Map::~Map()
{

}