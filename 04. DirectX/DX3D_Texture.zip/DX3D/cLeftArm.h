#pragma once
#include "cCubeNode.h"
class cLeftArm :
	public cCubeNode
{
public:
	cLeftArm();
	~cLeftArm();
	virtual void Setup() override; 
};

